#!/bin/bash
java -jar md5checksum.jar
read -p "Press any key to continue..."
