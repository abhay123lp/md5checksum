	*** md5checksum v0.1 ***
	   by Daniele Migliau

Simple program which calculates md5sums.

To calculate md5sums:
	put md5checksum.jar and md5checksum.bat into the folder containing the files to be checked.
	Windows        : double click checksum.bat
	Mac OS X/Linux : double click checksum.sh
	Terminal       : java -jar md5checksum.jar 


A file (md5sum.xml) will be created. Now just zip the whole folder and send it!

To check if what you received is correct:
	Windows        : double click checksum.bat
	Mac OS X/Linux : double click checksum.sh
	Terminal       : java -jar md5checksum.jar 

Feel free to redistribute!

Daniele Migliau